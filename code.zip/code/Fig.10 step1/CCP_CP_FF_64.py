import tensorflow as tf
import numpy as np
import cv2 as cv
import os
from  Get_data import get_data
import matplotlib.pyplot as plt
import time
import random
import sys
import math
import pandas as pd
import gc

#hype params
img_size = 32
img_size1 = 32
img_size2 = 32
depth = 1
batch_size = 64
lr = 0.0001
max_episode = 3000
step = 100
num = 10
testTime = 0
# temporyTime = 0

#placeholder
img_x = tf.placeholder(tf.float32, [batch_size, img_size1 , img_size2 ])
tf_y = tf.placeholder(tf.int32, [None, 15])
trainResult = np.zeros(shape=(int(max_episode/step)+1,3))
testResult = np.zeros(shape=(int(max_episode/step)+1,1))


class CNN(object):
    def __init__(self,lr,sess,dataPath):
        self.lr = lr
        self.class_prob = self.cnn_net(img_x,'CNN')
        self.sess = sess
        self.j = tf.losses.softmax_cross_entropy(logits=self.class_prob,onehot_labels=tf_y)
        self.trainop = tf.train.RMSPropOptimizer(lr).minimize(self.j)
        self.trainNum = 0
        self.testNum = 0
        self.dataPath = dataPath
        # self.trainTime = 0
        self.temporyTime = 0

    def cnn_net(self,x,scope):
        with tf.variable_scope(scope):
            init_w = tf.contrib.layers.xavier_initializer()
            init_b = tf.truncated_normal_initializer(0.0,0.01)

            img = tf.reshape(x,[batch_size,img_size1,img_size2,depth])
            net1 = tf.layers.conv2d(img,64,5,1,'valid',activation=tf.nn.relu,
                                   kernel_initializer=init_w,bias_initializer=init_b,trainable=True,name='l1',reuse=tf.AUTO_REUSE)
            net1_1 = tf.layers.conv2d(net1, 64, 5, 1, 'valid', activation=tf.nn.relu,
                                    kernel_initializer=init_w, bias_initializer=init_b, trainable=True, name='l1_1',
                                    reuse=tf.AUTO_REUSE)
            pool1 = tf.layers.max_pooling2d(net1_1,2,2,'valid',name='pool1')#14*  *6    #5

            net2 = tf.layers.conv2d(pool1,64,5,1,'valid',activation=tf.nn.relu,
                                   kernel_initializer=init_w,bias_initializer=init_b,trainable=True,name='l2',reuse=tf.AUTO_REUSE)
            pool2 = tf.layers.max_pooling2d(net2,2,2,'valid',name='pool2')#5*  *16    #5

            net3 = tf.layers.conv2d(pool2,120,4,1,'valid',activation=tf.nn.relu,
                                   kernel_initializer=init_w,bias_initializer=init_b,trainable=True,name='l3',reuse=tf.AUTO_REUSE)
            flatten = tf.layers.flatten(net3)
            net4 = tf.layers.dense(flatten, 84, kernel_initializer=init_w, use_bias=False,
                                  trainable=True, name='l4', reuse=tf.AUTO_REUSE)
            self.prob = tf.layers.dense(net4, 15, kernel_initializer=init_w, use_bias=False,
                                   trainable=True, name='l5', reuse=tf.AUTO_REUSE)
            # net2 = tf.layers.dense(net1,15,kernel_initializer=init_w,use_bias=False,
            #                        trainable=True,name='l6',reuse=tf.AUTO_REUSE)
            # self.prob = tf.nn.softmax(net2,name='prob')
            return self.prob

    def train(self,img,label,i):

        feed_dict = {img_x:img,tf_y:label}
        _,prob ,j= self.sess.run([self.trainop,self.prob,self.j],feed_dict=feed_dict)
        # print(str(i) + ": " + str(j))

        if (i+1)%step==0 and i > 1500:

            # print(i)
            print(str(i+1) + ": " + str(j))
            # print(np.argmax(prob,1))
            # print(np.argmax(label,1))
            trainAccuracy = np.sum(np.equal(np.argmax(prob,1),np.argmax(label,1)))/len(prob)
            print(str(i+1) + ("trainAccuracy:") + str(trainAccuracy))
            trainResult[self.trainNum, 2] = j
            trainResult[self.trainNum , 1] = trainAccuracy
            trainResult[self.trainNum , 0] = self.trainNum+1
            self.trainNum += 1
            # print(j)
            # print(i)

    def eval(self):
        nextX_zip, _,nextY_dense_zip = get_data(batch_size,self.dataPath,False)
        batches_in_epoch = len(nextY_dense_zip) // batch_size
        accuracy = 0

        temporyTimeStart = time.clock()
        for i in range(batches_in_epoch):
            nextX = nextX_zip[i * batch_size:(i + 1) * batch_size, :, :]
            nextY_dense = nextY_dense_zip[i * batch_size:(i + 1) * batch_size, :]
            feed_dict = {img_x: nextX}
            py = self.sess.run(self.prob, feed_dict=feed_dict)
            acc = np.mean(np.equal(np.argmax(py,1), nextY_dense.flatten()))

            accuracy += acc
        accuracy /= batches_in_epoch
        testResult[self.testNum, 0] = accuracy
        self.testNum += 1

        print(("ACCURACY: " + str(accuracy)))
        temporyTimeEnd = time.clock()
        self.temporyTime = self.temporyTime + temporyTimeEnd - temporyTimeStart



with tf.Session() as sess:
    dataPath = './ShaftOrbit/'
    cnn = CNN(lr,sess,dataPath)
    init = tf.global_variables_initializer()
    sess.run(init)
    sess.run(tf.local_variables_initializer())
    startTime = time.clock()
    for i in range(max_episode):
        img, y_hot, _ = get_data(batch_size,dataPath)
        max_value = np.max(img,(1,2))
        img = img/np.tile(max_value,(32,32,1)).reshape([batch_size,32,32])
        cnn.train(img,y_hot,i)
        # print(i)
        testTimeStart = time.clock()
        if (i+1)%(step*1 )==0 and  i>1500:
            # print(i)
            cnn.eval()
            cnn.lr = np.max([cnn.lr *0.99,0.0001])
        testTimeSEnd = time.clock()
        testTime = testTime + testTimeSEnd - testTimeStart

    endTime = time.clock()
    AllTime = endTime - startTime
    trainTime = AllTime - testTime  - cnn.temporyTime
    testTimeStat = time.clock()
    cnn.eval()
    testTimeEnd = time.clock()
    testTimeFinal = testTimeEnd - testTimeStat

    print('train time :' + str(trainTime))
    print('test time :' + str(testTimeFinal))
    result = np.hstack((trainResult,testResult))
    position = np.where(result == result[0:int(max_episode/step), 3].max())
    print('Train accuracy: ' + str((result[0:int(max_episode / step), 1].max())))
    print('Test accuracy: ' + str(result[position[0][0], 3]))
    print('Loss value: ' + str(result[position[0][0], 2]))









