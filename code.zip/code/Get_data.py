import cv2 as cv
import os
import random
import numpy as np
import matplotlib.pyplot as plt # plt 用于显示图片
import matplotlib.image as mpimg # mpimg 用于读取图片



def get_data(batch_size,dataPath,train=True):
    if train:
        # dir_list = os.listdir('/home/robot/Data/gc/g_c_'+str(img_size))
        # read_dir = '/home/robot/Data/gc/g_c_'+str(img_size)+'/'
        dir_list = os.listdir(dataPath + 'train')
        read_dir = dataPath + 'train/'
    else:
        dir_list = os.listdir(dataPath + 'test')
        read_dir = dataPath + 'test/'
        batch_size = len(dir_list)
        # print(batch_size)

    choosed_data= random.sample(dir_list,batch_size)

    #根据选择的数据获得图片数据和label
    img = np.zeros([batch_size,32,32])
    label_dense = np.zeros([batch_size,1])
    label = np.zeros([batch_size,15])
    count = 0

    for i in choosed_data:
        img1= cv.imread(read_dir+i,0)
        # print(img1.shape[0])
        # lena = mpimg.imread(read_dir+i)
        # lena.shape  # (512, 512, 3)
        # plt.imshow(lena)  # 显示图片
        # plt.axis('off')  # 不显示坐标轴
        # plt.show()

        # img1 = junhenghua(img111)

        # img111 = img111.astype(np.float64)
        # img1 = Retinex.multiScaleRetinex(img111, [10, 45, 100])
        # img1 = img1.astype(np.float64)

        # img111 = cv.resize(img111,(img_size,img_size),interpolation=cv.INTER_CUBIC)
        # img111 = clahe.apply(cv.imread(read_dir + i, 0))

        img[count, :, :] = img1
        label_dense[count,0] = int(i[0:2])
        label[count, int( label_dense[count,0])] = 1
        count = count+1
    # label = label.flatten()
    return img,label,label_dense
